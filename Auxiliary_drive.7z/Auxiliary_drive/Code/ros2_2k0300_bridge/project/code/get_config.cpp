#include "get_config.h"
#include "zf_common_headfile.h"


pthread_mutex_t g_tcp_sensor_mutex = PTHREAD_MUTEX_INITIALIZER;
